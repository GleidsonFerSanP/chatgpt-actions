import { google } from "googleapis";

// Utility function to validate required environment variables
function validateEnvVariables() {
  const {
    GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET,
    GOOGLE_REDIRECT_URI,
    REFRESH_TOKEN,
  } = process.env;

  if (
    !GOOGLE_CLIENT_ID ||
    !GOOGLE_CLIENT_SECRET ||
    !GOOGLE_REDIRECT_URI ||
    !REFRESH_TOKEN
  ) {
    throw new Error(
      "Missing required environment variables: GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI, or REFRESH_TOKEN."
    );
  }

  return {
    GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET,
    GOOGLE_REDIRECT_URI,
    REFRESH_TOKEN,
  };
}

// Function to initialize OAuth2 client
function initializeOAuth2Client() {
  const {
    GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET,
    GOOGLE_REDIRECT_URI,
    REFRESH_TOKEN,
  } = validateEnvVariables();

  const oAuth2Client = new google.auth.OAuth2(
    GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET,
    GOOGLE_REDIRECT_URI
  );
  oAuth2Client.setCredentials({ refresh_token: REFRESH_TOKEN });

  return oAuth2Client;
}

async function fetchAllContacts(nextPageToken = null) {
  const people = google.people("v1");
  const oAuth2Client = initializeOAuth2Client();

  try {
    const response = await people.people.connections.list({
      auth: oAuth2Client,
      resourceName: "people/me",
      pageSize: 100, // Maximum contacts per request
      personFields: "names, emailAddresses, phoneNumbers,organizations", // Specify fields to retrieve
      pageToken: nextPageToken, // For paginated results
    });

    console.log(`contacts fetched`, response);
    return response.data;
  } catch (error) {
    console.error("Error fetching contacts:", error.message);
    throw error;
  }
}

// Lambda handler function
export const handler = async (event) => {
  console.log("Start lambda", event);
  const queryParams = event.queryStringParameters;
  try {
    const contacts = await fetchAllContacts(queryParams?.nextPageToken);
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Contacts retrieved successfully.",
        contacts,
      }),
    };
  } catch (error) {
    console.error("Error handling request:", error.message);

    return {
      statusCode: error.statusCode || 500,
      body: JSON.stringify({
        message: "An error occurred while processing your request.",
        error: error.message,
      }),
    };
  }
};
